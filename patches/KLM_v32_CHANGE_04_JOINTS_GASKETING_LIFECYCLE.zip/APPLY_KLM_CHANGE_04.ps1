﻿#requires -Version 5.1
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Project = Join-Path ([Environment]::GetFolderPath("UserProfile")) "KLM-v32-recovery\source"
$Patch = Join-Path $PSScriptRoot "patch"
$CheckpointRoot = Join-Path ([Environment]::GetFolderPath("UserProfile")) "KLM-v32-checkpoints"
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Checkpoint = Join-Path $CheckpointRoot ("before-change-04-" + $Stamp)
$Wrangler = Join-Path $Project "wrangler.jsonc"
$VinextCli = Join-Path $Project "node_modules\vinext\dist\cli.js"

$Changed = @(
"app\components\ManufacturingRulesPanel.tsx",
"app\data\approvedCodeAliases.json",
"app\data\approvedRulesRegistry.json",
"app\klm-theme.css",
"app\lib\calculation.ts",
"app\lib\manufacturingRules.ts",
"app\page.tsx",
"tests\manufacturing-rules.test.mjs",
"tests\joint-separation-and-gasketing.test.mjs",
"public\references\rules\01.312.012.pdf",
"public\references\rules\012.001.000-IP55-6mm-4P.pdf",
"public\references\rules\583.001.PDF",
"public\references\rules\781.005.pdf",
"public\references\rules\approved-registry-2026-08-27.xlsx",
"public\references\rules\norms-KO-6.0-2026-06-01.xlsx",
"public\references\rules\norms-PO-1.0-2026-06-01.xlsx",
"public\references\rules\production-norms-2026-08-01.xlsx"
)

function Step([string]$Text) {
  Write-Host ""
  Write-Host "============================================================" -ForegroundColor DarkGray
  Write-Host $Text -ForegroundColor Cyan
  Write-Host "============================================================" -ForegroundColor DarkGray
}

function Invoke-Checked([string]$Exe,[string[]]$Arguments,[string]$Title) {
  Write-Host ("-> " + $Exe + " " + ($Arguments -join " ")) -ForegroundColor Gray
  & $Exe @Arguments
  $code = $LASTEXITCODE
  if ($code -ne 0) { throw ("{0} завершилась с кодом {1}" -f $Title,$code) }
}

function Restore-Checkpoint {
  foreach ($rel in $Changed) {
    $saved = Join-Path $Checkpoint $rel
    $target = Join-Path $Project $rel
    $missing = $saved + ".MISSING"
    if (Test-Path -LiteralPath $saved) {
      $parent = Split-Path -Parent $target
      if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
      Copy-Item -LiteralPath $saved -Destination $target -Force
    } elseif (Test-Path -LiteralPath $missing) {
      if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
    }
  }
}

try {
  Step "KLM v32 — CHANGE 04: стыки G, Gasketing, КД и жизненный цикл"

  if (-not (Test-Path -LiteralPath $Project)) { throw ("Не найден проект: " + $Project) }
  if (-not (Test-Path -LiteralPath $Patch)) { throw "Не найдена папка patch." }
  if (-not (Test-Path -LiteralPath $Wrangler)) { throw "Не найден wrangler.jsonc." }
  if (-not (Test-Path -LiteralPath $VinextCli)) { throw "Не найден локальный Vinext CLI." }

  Step "1/5. Checkpoint текущей рабочей версии"
  New-Item -ItemType Directory -Path $Checkpoint -Force | Out-Null
  foreach ($rel in $Changed) {
    $target = Join-Path $Project $rel
    $saved = Join-Path $Checkpoint $rel
    $parent = Split-Path -Parent $saved
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    if (Test-Path -LiteralPath $target) {
      Copy-Item -LiteralPath $target -Destination $saved -Force
    } else {
      New-Item -ItemType File -Path ($saved + ".MISSING") -Force | Out-Null
    }
  }
  Copy-Item -LiteralPath $Wrangler -Destination (Join-Path $Checkpoint "wrangler.jsonc") -Force
  Write-Host ("Checkpoint: " + $Checkpoint) -ForegroundColor Green

  Step "2/5. Установка утвержденных изменений"
  foreach ($rel in $Changed) {
    $from = Join-Path $Patch $rel
    $to = Join-Path $Project $rel
    if (-not (Test-Path -LiteralPath $from)) { throw ("Нет файла patch: " + $rel) }
    $parent = Split-Path -Parent $to
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    Copy-Item -LiteralPath $from -Destination $to -Force
  }

  Step "3/5. Чистая сборка"
  Push-Location $Project
  try {
    $dist = Join-Path $Project "dist"
    if (Test-Path -LiteralPath $dist) { Remove-Item -LiteralPath $dist -Recurse -Force }
    Invoke-Checked "node.exe" @($VinextCli,"build") "vinext build"
    if (-not (Test-Path -LiteralPath (Join-Path $Project "dist\client"))) { throw "После сборки отсутствует dist\client." }
    $css = @(Get-ChildItem -LiteralPath (Join-Path $Project "dist\client") -Recurse -File -Filter "*.css")
    if ($css.Count -eq 0) { throw "После сборки отсутствует CSS." }
    Write-Host ("CSS files: " + $css.Count) -ForegroundColor Green
  } finally { Pop-Location }

  Step "4/5. Все тесты"
  Push-Location $Project
  try {
    $tests = @(Get-ChildItem -LiteralPath (Join-Path $Project "tests") -Filter "*.test.mjs" | Sort-Object Name | ForEach-Object { $_.FullName })
    Write-Host ("Test files: " + $tests.Count) -ForegroundColor Gray
    & node.exe --test @tests
    if ($LASTEXITCODE -ne 0) { throw "Тесты не прошли." }
  } finally { Pop-Location }

  Step "5/5. Deploy"
  Push-Location $Project
  try {
    Invoke-Checked "npx.cmd" @("wrangler","deploy","--config",$Wrangler) "wrangler deploy"
  } finally { Pop-Location }

  Step "ГОТОВО"
  Write-Host "Обновление опубликовано:" -ForegroundColor Green
  Write-Host "https://klm-v32.bannikov-06.workers.dev" -ForegroundColor Green
  Write-Host ("Checkpoint: " + $Checkpoint) -ForegroundColor Gray
  Write-Host ""
  Write-Host "Внедрено:" -ForegroundColor Cyan
  Write-Host "- стыки G только если они есть отдельной строкой в спецификации" -ForegroundColor Gray
  Write-Host "- стыки G полностью исключены из состава секции" -ForegroundColor Gray
  Write-Host "- отдельный блок потребности по стыковочным элементам" -ForegroundColor Gray
  Write-Host "- состав G по актуальной КД 012.001.000СБ / G.001.000СБ" -ForegroundColor Gray
  Write-Host "- Gasketing: геометрия КД, 20 г/м, А:Б=100:20" -ForegroundColor Gray
  Write-Host "- компонент А Ц0000060428, компонент Б Ц0000057680" -ForegroundColor Gray
  Write-Host "- 6 мм -> 6x65; 7 мм -> 7x75 как управляемое правило" -ForegroundColor Gray
  Write-Host "- новый реестр кодов/правил без вопросительных статусов" -ForegroundColor Gray
  Write-Host "- меню сгруппировано по жизненному циклу предприятия" -ForegroundColor Gray
  Write-Host "- Ухо PE остается собственным производством: материал + операции" -ForegroundColor Gray
  Read-Host "Нажмите Enter для выхода"
}
catch {
  Write-Host ""
  Write-Host "ОШИБКА. Deploy не должен считаться принятым." -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  if (Test-Path -LiteralPath $Checkpoint) {
    try {
      Restore-Checkpoint
      Write-Host "Файлы проекта восстановлены из checkpoint." -ForegroundColor Green
    } catch {
      Write-Host "Автоматический rollback не завершился. Не запускайте deploy вручную." -ForegroundColor Red
    }
  }
  Write-Host "D1 и R2 не изменялись." -ForegroundColor Yellow
  Write-Host "Пришлите скрин последних строк." -ForegroundColor Yellow
  Read-Host "Нажмите Enter для выхода"
  exit 1
}
