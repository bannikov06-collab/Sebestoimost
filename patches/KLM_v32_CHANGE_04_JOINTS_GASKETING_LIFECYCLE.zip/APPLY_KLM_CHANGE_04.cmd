@echo off
chcp 65001 >nul
title KLM v32 Change 04 - Joints and Gasketing
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_KLM_CHANGE_04.ps1"
pause
