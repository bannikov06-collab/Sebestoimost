KLM v32 — CHANGE 05J

This updater adds:
- independent 14-day project snapshots for CBR USD/RUB + LME Al/Cu, with asymmetric update rule (rise updates, fall keeps previous);
- automatic production-order objects, priority 1/2/3/4 with up/down controls and highlighting until assigned;
- production readiness dates on independent department calendars, 12 hours/day, 7 days/week; only confirmed operation norms are loaded;
- multi-project selection for combined material requirements;
- material availability buckets: warehouse / in transit / paid / at supplier production;
- project material reservations with mandatory transfer confirmation and an immutable operation journal;
- Reservations moved to the first item under section 05.

Run: APPLY_KLM_CHANGE_05J.cmd
Working URL remains: https://klm-v32.bannikov-06.workers.dev
The updater checkpoints, verifies hashes, clean-builds, runs all tests, git-commits and only then deploys. On failure it restores changed files.
