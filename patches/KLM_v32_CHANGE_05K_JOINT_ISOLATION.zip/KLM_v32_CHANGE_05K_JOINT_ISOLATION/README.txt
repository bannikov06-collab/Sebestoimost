KLM v32 — CUMULATIVE CHANGE 05K (05I -> 05K)

This cumulative updater installs directly over the working CHANGE 05I source.
It includes all CHANGE 05J functions:
- automatic market snapshots and the independent 14-day USD/Al/Cu rule;
- production-order objects, priority queue and department calendars;
- multi-project material calculation;
- warehouse availability buckets and project reservations with audit history.

It also enforces strict isolation of joint G:
- joint rows are classified before section families;
- no joint can become FE/CD/CP/ZD/ZDP or another section;
- L1/L2/L3 are always zero;
- the joint is calculated only in its own block from 012.001.000СБ / G.001.000СБ;
- incomplete joint rows remain isolated and are flagged for nominal-current review.

The patch does not change D1/R2 bindings or the site address.

Run: APPLY_KLM_CHANGE_05K.cmd
CHANGE 05J does not need to be installed separately.
The updater checks the cumulative CHANGE 05I source, verifies hashes, creates a
checkpoint, clean-builds, runs all tests, creates a Git commit and deploys only
after every check passes. If a step fails, changed files are restored.
