import test from "node:test";
import assert from "node:assert/strict";
import { resolveFormulaCode } from "../app/lib/sectionFormulaCode.ts";

test("Pi straight section uses FE calculation family", () => {
  assert.equal(resolveFormulaCode({ id: 46, code: "Pi", name: "Нестандартная прямая секция длиной от 1000мм до 1999мм" }), "FE");
});

test("FE length classes use FE calculation family", () => {
  assert.equal(resolveFormulaCode({ id: 91, code: "FE-S6", name: "Нестандартная прямая секция" }), "FE");
});

test("Pi with EC is not silently treated as ordinary FE", () => {
  assert.equal(resolveFormulaCode({ id: 45, code: "Pi - EC", name: "Нестандартная прямая секция с заглушкой" }), undefined);
});

test("plain ATT and CML catalog families resolve to their approved specialized models", () => {
  assert.equal(resolveFormulaCode({ id: 137, code: "ATT", name: "Терминальная секция трансформаторная" }), "ATT");
  assert.equal(resolveFormulaCode({ id: 115, code: "CML", name: "Компенсационная секция" }), "CML");
});

test("combined ATT/CML families are not silently mapped to the plain family", () => {
  assert.equal(resolveFormulaCode({ id: 133, code: "ATT+ZP", name: "ATT совмещенная с ZP" }), undefined);
  assert.equal(resolveFormulaCode({ id: 114, code: "CML+СD", name: "CML с нестандартным углом" }), undefined);
});

test('preliminary standard and SA aliases resolve to base calculation families', () => {
  assert.equal(resolveFormulaCode({ id: 116, code: 'CD-SA', name: 'Нестандартный горизонтальный угол' }), 'CD');
  assert.equal(resolveFormulaCode({ id: 109, code: 'CP-SA', name: 'Нестандартный вертикальный угол' }), 'CP');
  assert.equal(resolveFormulaCode({ id: 10, code: 'ZD-SA', name: 'Нестандартный горизонтальный Z-элемент' }), 'ZD');
  assert.equal(resolveFormulaCode({ id: 4, code: 'ZP-SA', name: 'Нестандартный вертикальный Z-элемент' }), 'ZP');
  assert.equal(resolveFormulaCode({ id: 13, code: 'ZDP-SA', name: 'Угол комбинированный с нестандартным углом' }), 'ZDP');
  assert.equal(resolveFormulaCode({ id: 90, code: 'FE-SZ', name: 'Прямая секция с заземлением' }), 'FE');
  assert.equal(resolveFormulaCode({ id: 65, code: 'Pi-1', name: 'Прямая секция стандартного размера' }), 'FE');
});
