"use client";

import { ChangeEvent, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { calculateStockLengthMetrics, matchStock } from "../lib/materialPlanning";
import { CONFIRMED_M6X16_DIN6921_CODE } from "../lib/stockRules";

export type MaterialDemand = {
  name: string;
  unit: string;
  qty: number;
  price: number;
  total: number;
  group: string;
  stockLengthM?: number;
  massKg?: number;
  metricBasis?: string;
};

export type StockItem = {
  name: string;
  unit: string;
  code: string;
  article: string;
  group: string;
  balance: number;
};

type Mode = "requirements" | "procurement";

type Props = {
  mode: Mode;
  projectName: string;
  items: MaterialDemand[];
  stock: StockItem[];
  setStock: (items: StockItem[]) => void;
  stockSource: string;
  setStockSource: (source: string) => void;
  onOpenRequirements: () => void;
  onOpenProcurement: () => void;
  onPersistStock?: (file: File, items: StockItem[], source: string) => Promise<void>;
};

export const initialStock: StockItem[] = [
  { name: "Порошковый материал порошок припойный ПОС 61", unit: "кг", code: "Ц0000059919", article: "", group: "материалы ДИМЕТ", balance: 345 },
  { name: "Пленка ПЭТ-Э, толщ. 250 мкм, ширина 1000 мм, Гост 24238-80", unit: "кг", code: "Ц0000078237", article: "", group: "ПЭТ пленки", balance: 1000.8 },
  { name: "Скотч электротехнический термостойкий 25мм*66м", unit: "шт", code: "УТ000000404", article: "Р.31/FY100", group: "ПЭТ пленки", balance: 1781 },
  { name: "Профиль алюминиевый АП 4178 E-V.68.140 крышка АД31 3000мм RAL7035 Шагрень", unit: "пог.м", code: "Ц0000074662", article: "АП 4178", group: "Листовые материалы и шины", balance: 5462.41 },
  { name: "Профиль алюминиевый АП 4977 E-V.180 полукорпус (боковина) секции 200 мм", unit: "пог.м", code: "Ц0000077016", article: "АП 4977", group: "Листовые материалы и шины", balance: 1977.31 },
  { name: "Болт М6*12, DIN 6921, с фланцем, цинк, кл. 8.8", unit: "шт", code: "Ц0000056270", article: "", group: "МЕТИЗЫ", balance: 8992 },
  { name: "Болт М6*16, DIN 6921, с фланцем, цинк, кл. 8.8", unit: "шт", code: CONFIRMED_M6X16_DIN6921_CODE, article: "", group: "МЕТИЗЫ", balance: 24000 },
  { name: "Гайка М6, DIN 6923, ГОСТ 50592-93, с фланцем, цинк", unit: "шт", code: "УТ000002046", article: "", group: "МЕТИЗЫ", balance: 7100 },
  { name: "Заклёпка 4,8*10 ст/ст", unit: "шт", code: "Ц0000039669", article: "", group: "МЕТИЗЫ", balance: 25500 },
  { name: "Пленкосинтокартон ПСК-515 0,30 мм", unit: "кг", code: "Ц0000056495", article: "", group: "ПЭТ пленки", balance: 545 },
  { name: "Герметик", unit: "шт", code: "2130", article: "", group: "Материалы на производство", balance: 226 },
  { name: "Стрейч-плёнка ручная, рулон 2,2 кг", unit: "шт", code: "00000004273", article: "", group: "Упаковочные материалы", balance: 0 },
  { name: "Шина АД0 6*30*3000 (R=3.0)", unit: "кг", code: "УТ000002292", article: "", group: "Листовые материалы и шины", balance: 408 },
  { name: "Шина АД0 6*50*3000 (R3)", unit: "кг", code: "Ц0000077017", article: "", group: "Листовые материалы и шины", balance: 1695 },
  { name: "Шина АД0 6*65*3000 (R=3)", unit: "кг", code: "Ц0000079245", article: "", group: "Листовые материалы и шины", balance: 0 },
  { name: "Шина АД0 6*100*3000 (R=3)", unit: "кг", code: "Ц0000072703", article: "", group: "Листовые материалы и шины", balance: 318 },
  { name: "Шина АД0 6*130*3000 (R=3)", unit: "кг", code: "Ц0000078399", article: "", group: "Листовые материалы и шины", balance: 12585 },
  { name: "Шина АД0 6*160*3000 (R=3)", unit: "кг", code: "Ц0000072624", article: "", group: "Листовые материалы и шины", balance: 12466 },
  { name: "Шина АД0 6*200*3000 (R=3)", unit: "кг", code: "Ц0000072623", article: "", group: "Листовые материалы и шины", balance: 11296 },
];

const normalize = (value: unknown) => String(value ?? "").toLowerCase().replace(/ё/g, "е").replace(/[×х]/g, "*").replace(/\s+/g, " ").trim();
const numeric = (value: unknown) => {
  const parsed = Number(String(value ?? "").replace(/\u00a0/g, "").replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : 0;
};

async function parseStockFile(file: File): Promise<StockItem[]> {
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true });
  let selected: unknown[][] | null = null;
  for (const sheetName of workbook.SheetNames) {
    const matrix = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[sheetName], { header: 1, defval: "", raw: false });
    if (matrix.some((row) => row.some((cell) => normalize(cell) === "конечный остаток"))) {
      selected = matrix;
      break;
    }
  }
  if (!selected) throw new Error("Не найден лист с колонкой «Конечный остаток».");
  const headerIndex = selected.findIndex((row) => row.some((cell) => normalize(cell) === "номенклатура") && row.some((cell) => normalize(cell) === "конечный остаток"));
  if (headerIndex < 0) throw new Error("Не найдена строка заголовков складского отчёта.");
  const headers = selected[headerIndex].map(normalize);
  const column = (name: string) => headers.findIndex((header) => header === normalize(name));
  const nameIndex = column("Номенклатура");
  const unitIndex = column("Базовая единица измерения");
  const codeIndex = column("Код");
  const articleIndex = column("Артикул");
  const groupIndex = headers.findIndex((header) => header.includes("группа"));
  const balanceIndex = column("Конечный остаток");
  const rows = selected.slice(headerIndex + 1).map((row) => ({
    name: String(row[nameIndex] ?? "").trim(),
    unit: String(row[unitIndex] ?? "").trim(),
    code: String(row[codeIndex] ?? "").trim(),
    article: String(row[articleIndex] ?? "").trim(),
    group: String(row[groupIndex] ?? "").trim(),
    balance: numeric(row[balanceIndex]),
  })).filter((row) => row.name && row.code && row.name !== "Основной склад-2");
  if (!rows.length) throw new Error("В складском отчёте не найдено строк номенклатуры.");
  return rows;
}

function downloadXlsx(projectName: string, rows: PlannedRow[]) {
  const header = ["Проект / заказ", "Код 1С", "Номенклатура", "Ед. изм.", "Потребность", "Масса, кг", "Шины / профиль 3000 мм, шт.", "Листы, шт.", "Остаток", "Резерв", "К заказу", "Расчётная сумма, руб.", "Статус"];
  const body = rows.map((row) => [
    projectName,
    row.code,
    row.stock?.name ?? row.name.replace(/^.*?\s*[·•-]\s*/, ""),
    row.stockUnit,
    row.demand,
    row.massKg === undefined ? "" : Math.round(row.massKg * 100) / 100,
    row.pieces3m ?? "",
    /лист/i.test(row.name) && /шт/i.test(row.stockUnit) ? Math.ceil(row.demand) : "",
    row.stock ? row.balance : "",
    0,
    row.stock ? row.shortage : "",
    row.stock ? Math.round(row.shortageCost * 100) / 100 : "",
    row.stock ? "Подтверждённый дефицит" : "Проверить остаток / единицу измерения",
  ]);
  const worksheet = XLSX.utils.aoa_to_sheet([header, ...body]);
  worksheet["!cols"] = [22,16,52,12,14,14,20,12,14,14,14,20,30].map((wch) => ({ wch }));
  worksheet["!autofilter"] = { ref: `A1:M${body.length + 1}` };
  worksheet["!freeze"] = { xSplit: 0, ySplit: 1 };
  for (let row = 2; row <= body.length + 1; row++) {
    for (const column of ["F", "L"]) if (worksheet[`${column}${row}`]) worksheet[`${column}${row}`].z = "0.00";
  }
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Заказ материалов");
  const data = XLSX.write(workbook, { type: "array", bookType: "xlsx" });
  const blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `Заказ_материалов_${projectName.replace(/[^a-zа-я0-9]+/gi, "_")}.xlsx`;
  anchor.click();
  URL.revokeObjectURL(url);
}

type PlannedRow = {
  key: string;
  name: string;
  group: string;
  demand: number;
  stockUnit: string;
  balance: number;
  available: number;
  shortage: number;
  shortageCost: number;
  code: string;
  stock?: StockItem;
  reason: string;
  massKg?: number;
  pieces3m?: number;
  metricBasis?: string;
  stockLengthM?: number;
};

export default function MaterialsPlanningPanel(props: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState("");
  const number = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 3 });
  const money = new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 });

  const planned = useMemo<PlannedRow[]>(() => {
    const rows = new Map<string, PlannedRow>();
    props.items.forEach((item) => {
      const match = matchStock(item, props.stock);
      const code = match.stock?.code || match.demandCode;
      const key = code || `unmatched:${item.name}`;
      const demand = item.qty * match.factor;
      const balance = match.stock?.balance ?? 0;
      const old = rows.get(key);
      const totalDemand = (old?.demand ?? 0) + demand;
      const shortage = match.stock ? Math.max(totalDemand - Math.max(balance, 0), 0) : 0;
      const totalStockLengthM = (old?.stockLengthM ?? 0) + (item.stockLengthM ?? 0);
      const totalMassKg = (old?.massKg ?? 0) + (item.massKg ?? 0);
      const metrics = calculateStockLengthMetrics({
        name: item.name,
        unit: item.unit,
        qty: totalDemand,
        price: item.price,
        stockLengthM: item.stockLengthM === undefined ? undefined : totalStockLengthM,
        massKg: item.massKg === undefined ? undefined : totalMassKg,
        metricBasis: item.metricBasis,
      });
      rows.set(key, {
        key,
        name: item.name,
        group: item.group,
        demand: totalDemand,
        stockUnit: match.stock?.unit ?? item.unit,
        balance,
        available: match.stock ? Math.min(totalDemand, Math.max(balance, 0)) : 0,
        shortage,
        shortageCost: shortage * item.price * match.priceFactor,
        code,
        stock: match.stock,
        reason: match.reason,
        massKg: metrics.massKg,
        pieces3m: metrics.pieces3m,
        metricBasis: metrics.basis,
        stockLengthM: item.stockLengthM === undefined ? undefined : totalStockLengthM,
      });
    });
    return [...rows.values()].sort((a, b) => Number(Boolean(b.shortage)) - Number(Boolean(a.shortage)) || a.name.localeCompare(b.name, "ru"));
  }, [props.items, props.stock]);

  const matched = planned.filter((row) => row.stock);
  const unresolved = planned.filter((row) => !row.stock);
  const missingBalance = unresolved.filter((row) => row.code);
  const missingCode = unresolved.filter((row) => !row.code);
  const procurement = planned.filter((row) => row.code && (row.stock ? row.shortage > 0 : true));
  const confirmedShortage = matched.filter((row) => row.shortage > 0);
  const totalNeed = confirmedShortage.reduce((sum, row) => sum + row.shortageCost, 0);
  const coverage = matched.reduce((sum, row) => sum + row.demand, 0) ? matched.reduce((sum, row) => sum + row.available, 0) / matched.reduce((sum, row) => sum + row.demand, 0) * 100 : 0;

  async function handleStock(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setLoading(true);
    setError("");
    try {
      const rows = await parseStockFile(file);
      const source = `${file.name} · лист с колонкой «Конечный остаток»`;
      if (props.onPersistStock) await props.onPersistStock(file, rows, source);
      props.setStock(rows);
      props.setStockSource(source);
      setLastUpdated(new Date().toLocaleString("ru-RU"));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Не удалось прочитать складской файл.");
    } finally {
      setLoading(false);
      event.target.value = "";
    }
  }

  return <div className="materials-planning">
    <div className="materials-head panel">
      <div>
        <p className="eyebrow">Проект / заказ</p>
        <h2>{props.projectName}</h2>
        <span>Источник остатков: {props.stockSource}</span>
        <small>Последнее успешное обновление: {lastUpdated || "в текущем сеансе ещё не выполнялось"} · режим: ручной{error ? ` · последняя ошибка: ${error}` : " · ошибок последнего импорта нет"}</small>
      </div>
      <div className="materials-actions">
        <input ref={inputRef} type="file" accept=".xlsm,.xlsx,.xls" onChange={handleStock} hidden />
        <button className="stock-upload" onClick={() => inputRef.current?.click()} disabled={loading}>{loading ? "Читаю остатки…" : "Обновить остатки из Excel"}</button>
        <small>Используется «Конечный остаток» по каждой позиции</small>
      </div>
    </div>
    {error && <p className="import-error">{error}</p>}

    <div className="material-tabs" role="tablist" aria-label="Планирование материалов">
      <button className={props.mode === "requirements" ? "active" : ""} onClick={props.onOpenRequirements}>Потребность и склад</button>
      <button className={props.mode === "procurement" ? "active" : ""} onClick={props.onOpenProcurement}>Заказ материалов <span>{procurement.length}</span></button>
    </div>

    {props.mode === "requirements" ? <>
      <div className="composition-kpis materials-kpis">
        <div><span>Материалов в расчёте</span><strong>{planned.length}</strong><small>сводные позиции</small></div>
        <div><span>Сопоставлено со складом</span><strong>{matched.length}</strong><small>по коду или строгому правилу</small></div>
        <div className={confirmedShortage.length ? "risk" : "ok"}><span>Дефицитных позиций</span><strong>{confirmedShortage.length}</strong><small>{missingBalance.length} позиций требуют проверки остатка</small></div>
        <div className={missingCode.length ? "risk" : "ok"}><span>Без подтверждённого кода</span><strong>{missingCode.length}</strong><small>{missingBalance.length} кодов нет в остатках</small></div>
      </div>
      <div className="panel composition material-table-panel">
        <div className="panel-title"><div><span>01</span><h2>Потребность с учётом остатков</h2></div><small>покрытие подтверждённых позиций {number.format(coverage)}%</small></div>
        <div className="table-wrap"><table className="materials-table"><thead><tr><th>Материал расчёта</th><th>Код / позиция склада</th><th>Потребность</th><th>Остаток</th><th>К заказу</th><th>Статус</th></tr></thead><tbody>
          {planned.map((row) => <tr key={row.key} className={!row.stock ? "mapping-row" : row.shortage > 0 ? "shortage-row" : "covered-row"}>
            <td><small>{row.group}</small><strong>{row.name}</strong></td>
            <td>{row.stock ? <><small>{row.stock.code}</small><span>{row.stock.name}</span></> : row.code ? <><small>{row.code}</small><span>Код подтверждён; нет строки в остатках</span></> : <span>Код не подтверждён</span>}</td>
            <td>{number.format(row.demand)} {row.stockUnit}{row.massKg !== undefined && <small>{number.format(row.massKg)} кг · {row.pieces3m} шт. × 3000 мм</small>}</td><td>{row.stock ? `${number.format(row.balance)} ${row.stockUnit}` : "—"}</td><td>{row.stock ? <strong>{number.format(row.shortage)} {row.stockUnit}</strong> : "—"}</td>
            <td><span className={`planning-status ${!row.stock ? row.code ? "no-stock" : "mapping" : row.shortage > 0 ? "shortage" : "covered"}`}>{!row.stock ? row.code ? "Нет в остатках" : "Уточнить код" : row.shortage > 0 ? "Дефицит" : "Покрыто"}</span><small>{row.reason}</small></td>
          </tr>)}
        </tbody></table></div>
      </div>
    </> : <>
      <div className="procurement-summary">
        <div><span>Позиций к заказу / проверке</span><strong>{procurement.length}</strong></div>
        <div><span>Подтверждённая сумма</span><strong>{money.format(totalNeed)}</strong><small>только дефицит с загруженным остатком</small></div>
        <button disabled={!procurement.length} onClick={() => downloadXlsx(props.projectName, procurement)}>Скачать XLSX для снабжения</button>
      </div>
      <div className="notice procurement-note"><b>Контроль перед отправкой</b><span>Подтверждённые коды без строки складского остатка включены в перечень с пометкой «Проверить остаток». Без кода 1С: {missingCode.length}. Требуют проверки остатка или единицы: {missingBalance.length}.</span></div>
      <div className="panel composition material-table-panel">
        <div className="panel-title"><div><span>02</span><h2>Заказ материалов для отдела снабжения</h2></div><small>{procurement.length} позиций с подтверждённым кодом</small></div>
        {procurement.length ? <div className="table-wrap"><table className="materials-table procurement-table"><thead><tr><th>Код 1С / номенклатура</th><th>Ед.</th><th>Потребность</th><th>Масса, кг</th><th>Заготовки 3000 мм, шт.</th><th>Остаток</th><th>Заказать</th><th>Расчётная сумма</th></tr></thead><tbody>
          {procurement.map((row) => <tr key={row.key} className={!row.stock ? "mapping-row" : "shortage-row"}><td><small>{row.code}</small><strong>{row.stock?.name ?? row.name.replace(/^.*?\s*[·•-]\s*/, "")}</strong>{row.metricBasis && <small>{row.metricBasis}</small>}</td><td>{row.stockUnit}</td><td>{number.format(row.demand)}</td><td>{row.massKg === undefined ? "—" : row.massKg.toFixed(2)}</td><td>{row.pieces3m === undefined ? "—" : <strong>{row.pieces3m}</strong>}</td><td>{row.stock ? number.format(row.balance) : "—"}</td><td>{row.stock ? <strong>{number.format(row.shortage)}</strong> : <span className="planning-status no-stock">Проверить остаток</span>}</td><td>{row.stock ? money.format(row.shortageCost) : "—"}</td></tr>)}
        </tbody></table></div> : <div className="empty">По подтверждённым складским позициям дефицита нет.</div>}
      </div>
      {missingCode.length > 0 && <div className="panel unresolved-panel"><div className="panel-title"><div><span>!</span><h2>Не включено в заказ</h2></div><small>{missingCode.length} позиций без кода 1С</small></div>{missingCode.map((row) => <div key={row.key}><strong>{row.name}</strong><span>{number.format(row.demand)} {row.stockUnit}</span><small>{row.reason}</small></div>)}</div>}
    </>}
  </div>;
}
