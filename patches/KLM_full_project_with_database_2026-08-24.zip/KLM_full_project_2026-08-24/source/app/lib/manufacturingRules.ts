export type PeEarRule = {
  currentA: number;
  designation: string;
  lengthMm: number;
  quantityPerSection: number;
};

export type JointComponent = {
  designation: string;
  name: string;
  material: string;
  quantity: number;
  source: "КД" | "Excel" | "КД + Excel";
};

export type JointRule = {
  currentA: number;
  designation: string;
  connectorDesignation: string;
  supportedBusbarThicknessMm: readonly [6, 7];
  heightMm: number;
  totalMassKg: number;
  connectorMassKg: number;
  components: JointComponent[];
};

export const PE_EAR_SOURCE = "260.045.pdf";
export const JOINT_DRAWING_SOURCE = "G.001.000(Шина 6мм-IP55_4P_крышка проф.).PDF";
export const JOINT_COMPOSITION_SOURCE = "Состав изделий G.001.000-G.001.000-11.xlsx";
export const PE_EAR_BLANK_WIDTH_MM = 113.52;
export const PE_EAR_THICKNESS_MM = 2;
export const AMG3_DENSITY_KG_M3 = 2700;

const peEarByCurrent: Record<number, Omit<PeEarRule, "currentA" | "quantityPerSection">> = {
  160: { designation: "260.045-20", lengthMm: 69 },
  250: { designation: "260.045-20", lengthMm: 69 },
  315: { designation: "260.045-20", lengthMm: 69 },
  400: { designation: "260.045-20", lengthMm: 69 },
  500: { designation: "260.045-21", lengthMm: 79 },
  630: { designation: "260.045", lengthMm: 89 },
  800: { designation: "260.045-01", lengthMm: 104 },
  1000: { designation: "260.045-04", lengthMm: 139 },
  1250: { designation: "260.045-05", lengthMm: 169 },
  1600: { designation: "260.045-06", lengthMm: 199 },
  2000: { designation: "260.045-08", lengthMm: 239 },
  2500: { designation: "260.045-10", lengthMm: 348 },
  3200: { designation: "260.045-11", lengthMm: 408 },
  4000: { designation: "260.045-13", lengthMm: 488 },
  5000: { designation: "260.045-15", lengthMm: 706 },
  6300: { designation: "260.045-16", lengthMm: 826 },
};

export function getPeEarRule(currentA: number): PeEarRule | undefined {
  const rule = peEarByCurrent[currentA];
  return rule ? { currentA, ...rule, quantityPerSection: 4 } : undefined;
}

export function calculatePeEarBlank(currentA: number, quantity = 4) {
  const rule = getPeEarRule(currentA);
  if (!rule) return undefined;
  const onePieceKg = PE_EAR_BLANK_WIDTH_MM / 1000 * rule.lengthMm / 1000 * PE_EAR_THICKNESS_MM / 1000 * AMG3_DENSITY_KG_M3;
  return {
    ...rule,
    quantity,
    onePieceKg,
    totalKg: onePieceKg * quantity,
    confidence: "Расчётно" as const,
    basis: `масса прямоугольной заготовки ${PE_EAR_BLANK_WIDTH_MM}×${rule.lengthMm}×${PE_EAR_THICKNESS_MM} мм; отверстия и отход раскроя не вычитаются`,
  };
}

type JointSeed = {
  currentA: number;
  suffix: string;
  heightMm: number;
  totalMassKg: number;
  connectorMassKg: number;
  springQty: number;
  bushingQty: number;
  busbarName: string;
  insulatorDesignation: string;
  insulatorName?: string;
  press2Name: string;
};

const jointSeeds: JointSeed[] = [
  { currentA: 400, suffix: "", heightMm: 69, totalMassKg: 1.8, connectorMassKg: 1.0, springQty: 2, bushingQty: 1, busbarName: "Шина стыка G 400А IP55", insulatorDesignation: "781.005", insulatorName: "Изолятор-IP55-4P/5P", press2Name: "Прижимной профиль стыка G 400А IP55" },
  { currentA: 630, suffix: "-01", heightMm: 89, totalMassKg: 2.1, connectorMassKg: 1.3, springQty: 2, bushingQty: 1, busbarName: "Шина стыка G 630А IP55", insulatorDesignation: "06A.G.01", press2Name: "Прижимной профиль стыка G 630А IP55" },
  { currentA: 800, suffix: "-02", heightMm: 104, totalMassKg: 2.4, connectorMassKg: 1.6, springQty: 2, bushingQty: 1, busbarName: "Шина стыка G 800А IP55 (Шина 7мм)", insulatorDesignation: "08A.G.01", press2Name: "Прижимной профиль стыка G 800А IP55 (Шина 6мм)" },
  { currentA: 1000, suffix: "-03", heightMm: 139, totalMassKg: 3.0, connectorMassKg: 2.2, springQty: 2, bushingQty: 1, busbarName: "Шина стыка G 1000А IP55", insulatorDesignation: "10A.G.01", press2Name: "Прижимной профиль стыка G 800А IP55 (Шина 7мм)" },
  { currentA: 1250, suffix: "-04", heightMm: 169, totalMassKg: 3.7, connectorMassKg: 2.9, springQty: 4, bushingQty: 2, busbarName: "Шина стыка G 1250А IP55", insulatorDesignation: "12A.G.01", press2Name: "Прижимной профиль стыка G 1000А IP55" },
  { currentA: 1600, suffix: "-05", heightMm: 199, totalMassKg: 4.2, connectorMassKg: 3.4, springQty: 4, bushingQty: 2, busbarName: "Шина стыка G 1600А IP55", insulatorDesignation: "16A.G.01", press2Name: "Прижимной профиль стыка G 1250А IP55" },
  { currentA: 2000, suffix: "-06", heightMm: 239, totalMassKg: 5.1, connectorMassKg: 4.3, springQty: 6, bushingQty: 3, busbarName: "Шина стыка G 2000А IP55", insulatorDesignation: "1S.20A.G.01", press2Name: "Прижимной профиль стыка G 1600А IP55" },
  { currentA: 2500, suffix: "-07", heightMm: 348, totalMassKg: 7.1, connectorMassKg: 6.3, springQty: 8, bushingQty: 4, busbarName: "Шина стыка G 2500А IP55", insulatorDesignation: "25A.G.01", press2Name: "Прижимной профиль стыка G 2000А IP55" },
  { currentA: 3200, suffix: "-08", heightMm: 408, totalMassKg: 8.0, connectorMassKg: 7.2, springQty: 8, bushingQty: 4, busbarName: "Шина стыка G 3200А IP55", insulatorDesignation: "1S.32A.G.01", press2Name: "Прижимной профиль стыка G 2500А IP55" },
  { currentA: 4000, suffix: "-09", heightMm: 488, totalMassKg: 9.8, connectorMassKg: 9.0, springQty: 12, bushingQty: 6, busbarName: "Шина стыка G 4000А IP55", insulatorDesignation: "V.40Al.G.01.05", press2Name: "Прижимной профиль стыка G 3200А IP55" },
  { currentA: 5000, suffix: "-10", heightMm: 706, totalMassKg: 13.5, connectorMassKg: 12.7, springQty: 16, bushingQty: 8, busbarName: "Шина стыка G 5000А IP55", insulatorDesignation: "781.005-01", insulatorName: "Изолятор-IP55-4P/5P 5000A", press2Name: "Прижимной профиль стыка G 4000А IP55" },
  { currentA: 6300, suffix: "-11", heightMm: 826, totalMassKg: 15.3, connectorMassKg: 14.5, springQty: 16, bushingQty: 8, busbarName: "Шина стыка G 6300А IP55", insulatorDesignation: "781.005-02", insulatorName: "Изолятор-IP55-4P/5P 6300A", press2Name: "Прижимной профиль стыка G 5000А IP55" },
];

function buildJointRule(seed: JointSeed): JointRule {
  const suffix = seed.suffix;
  const connectorDesignation = `012.001.000${suffix}`;
  const designation = `G.001.000${suffix}`;
  const components: JointComponent[] = [
    { designation: "01.312.012", name: "Крышка с уплотнителем", material: "по КД", quantity: 2, source: "КД" },
    { designation: `583.001${suffix}`, name: seed.busbarName, material: "Шина АД0 3,5×70 ГОСТ 15176-89", quantity: 10, source: "Excel" },
    { designation: "", name: "Пружина тарельчатая 60,0×13,0×5,0×1,5", material: "", quantity: seed.springQty, source: "Excel" },
    { designation: "03.212.001-03", name: "Втулка", material: "Трубка 044.000.008 pl", quantity: seed.bushingQty, source: "Excel" },
    { designation: "03.312.012", name: "Крышка стыка", material: "Профиль АП 4975", quantity: 2, source: "Excel" },
    { designation: `195.001${suffix}`, name: `Прижимной профиль стыка G ${seed.currentA}А IP55`, material: "Заготовка - профиль АП 5786", quantity: 1, source: "Excel" },
    { designation: `195.002${suffix}`, name: seed.press2Name, material: "Заготовка - профиль АП 5785", quantity: 1, source: "Excel" },
    { designation: seed.insulatorDesignation, name: seed.insulatorName ?? "Изолятор", material: seed.currentA === 400 ? "Поликарбонат монолитный 3,0" : seed.currentA >= 5000 ? "Поликарбонат" : "", quantity: 5, source: "Excel" },
    { designation: "", name: "Гайка DIN 985-M12-8.8", material: "", quantity: seed.bushingQty, source: "Excel" },
    { designation: "", name: "Gasketig", material: "Резина", quantity: 2, source: "Excel" },
    { designation: "", name: "Болт DIN 6921-M6×12-8.8", material: "", quantity: 16, source: "КД + Excel" },
    { designation: "", name: "Болт DIN 933-M12×130-8.8", material: "", quantity: seed.bushingQty, source: "Excel" },
  ];
  return { currentA: seed.currentA, designation, connectorDesignation, supportedBusbarThicknessMm: [6, 7], heightMm: seed.heightMm, totalMassKg: seed.totalMassKg, connectorMassKg: seed.connectorMassKg, components };
}

export const jointRules = jointSeeds.map(buildJointRule);

export function getJointRule(currentA: number) {
  return jointRules.find((rule) => rule.currentA === currentA);
}
